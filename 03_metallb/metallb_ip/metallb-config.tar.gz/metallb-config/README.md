# metallb-config

A [HELM](https://helm.sh/) chart for configuring 
[MetalLB](https://metallb.universe.tf/), the bare metal load balancer.

The chart currently implements all of the resources in the `metallb.io/v1beta1`
and `metallb.io/v1beta2` packages.

## Requirements

An already deployed MetalLB chart

## Configuration

To see all configurable options, visit the chart's `values.yaml` file.

The syntax of the resources is the same as listed on the 
[API reference documentation](https://metallb.universe.tf/apis/), with
minor variations:

- For the **BGPPeer** resource, the content of the `password` field will be
  saved in a _Secret_. For this reason, the `password` and `passwordSecret`
  fields are mutually exclusive
